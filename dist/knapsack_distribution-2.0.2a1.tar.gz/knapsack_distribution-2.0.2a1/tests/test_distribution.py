"""
Tools for calculating probabilistic choice distributions in knapsack problem instances.

This module provides the tests for functionality. These tests use the unittest package.
See README.md for full documentation and examples.


Copyright
---------
© 2026 Robert Woods - Code and implementation
© 2026 Roman Berlanger - Model and concept


License
-------
This program is free software under the GNU Affero General Public License v3.
See the LICENSE file for full terms.
"""

import unittest
import sys
import io

from src.knapsack_distribution import KnapsackItem, KnapsackInstance, ProblemType, get_node_distribution, print_node_distribution, solve_decision_variant, __version__
from src.knapsack_distribution.distribution import _get_knapsack_item_dominance_matrix, _validate_parameters_and_value_threshold


class TestModelVersion(unittest.TestCase):

    def test_version(self):
        """ Check that the version of `knapsack_cls` matches the model used to calculate these tests.

        Some of these tests use a manually calculated knapsack instance for comparison to the output
        of the package. They rely on a specific knapsack instance, specific parameters, and a specific
        version of the distribution model. Changing any of these may change the results, and these
        tests will no longer work.
        """
        self.assertEqual(__version__.split(".")[0], "2")
        self.assertEqual(__version__.split(".")[1], "0")


class TestDominanceMatrix(unittest.TestCase):
    def test_item_dominance(self):
        """ Test dominance of `KnapsackItem`s.

        Items with higher value for the same (or less) weight dominate.
        Items with lower weight for the same (or less) value dominate.

        A dominates B dominates C.
        D is not dominated, nor dominates any item."""

        knapsack_item_A = KnapsackItem(30, 10)
        knapsack_item_B = KnapsackItem(20, 20)
        knapsack_item_C = KnapsackItem(10, 20)
        knapsack_item_D = KnapsackItem(5, 5)

        knapsack_items = [knapsack_item_A, knapsack_item_B, knapsack_item_C, knapsack_item_D]

        knapsack_item_dominance_matrix = _get_knapsack_item_dominance_matrix(knapsack_items)

        self.assertFalse(any(hash(knapsack_item) in knapsack_item_dominance_matrix[hash(knapsack_item_A)] for knapsack_item in [knapsack_item_B, knapsack_item_C, knapsack_item_D]))

        self.assertTrue(all(hash(knapsack_item) in knapsack_item_dominance_matrix[hash(knapsack_item_B)] for knapsack_item in [knapsack_item_A]))
        self.assertFalse(any(hash(knapsack_item) in knapsack_item_dominance_matrix[hash(knapsack_item_B)] for knapsack_item in [knapsack_item_C, knapsack_item_D]))

        self.assertTrue(expr=all(hash(knapsack_item) in knapsack_item_dominance_matrix[hash(knapsack_item_C)] for knapsack_item in [knapsack_item_A, knapsack_item_B]))
        self.assertFalse(any(hash(knapsack_item) in knapsack_item_dominance_matrix[hash(knapsack_item_C)] for knapsack_item in [knapsack_item_D]))

        self.assertFalse(any(hash(knapsack_item) in knapsack_item_dominance_matrix[hash(knapsack_item_D)] for knapsack_item in [knapsack_item_A, knapsack_item_B, knapsack_item_C]))

    def test_repeated_item_dominance(self):
        """ Test dominance of repeated `KnapsackItem`s.

        To allow for simplification of knapsack instances with repeated identical items (same value and weight),
        an arbitrary dominance between repeated items is applied which is that early items dominate later items.
        """

        knapsack_item_A = KnapsackItem(30, 10)
        knapsack_item_B = KnapsackItem(30, 10)
        knapsack_item_C = KnapsackItem(30, 10)

        knapsack_items = [knapsack_item_A, knapsack_item_B, knapsack_item_C]

        knapsack_item_dominance_matrix = _get_knapsack_item_dominance_matrix(knapsack_items)

        self.assertFalse(any(hash(knapsack_item) in knapsack_item_dominance_matrix[hash(knapsack_item_A)] for knapsack_item in [knapsack_item_B, knapsack_item_C]))

        self.assertTrue(all(hash(knapsack_item) in knapsack_item_dominance_matrix[hash(knapsack_item_B)] for knapsack_item in [knapsack_item_A]))
        self.assertFalse(any(hash(knapsack_item) in knapsack_item_dominance_matrix[hash(knapsack_item_B)] for knapsack_item in [knapsack_item_C]))

        self.assertTrue(expr=all(hash(knapsack_item) in knapsack_item_dominance_matrix[hash(knapsack_item_C)] for knapsack_item in [knapsack_item_A, knapsack_item_B]))

    def test_invalid_self_dominance(self):
        """ Test setting invalid dominance (self dominance). """

        with self.assertRaises(ValueError):
            value = 10
            weight = 30

            knapsack_item = KnapsackItem(value, weight)

            knapsack_items = [knapsack_item, knapsack_item]

            _get_knapsack_item_dominance_matrix(knapsack_items)



class TestValidation(unittest.TestCase):
    def test_validate_parameters_and_value_threshold(self):
        """ Test `_validate_parameters_and_value_threshold`

        Does not cover all possibilities, but many."""
        safe_alpha = safe_beta = safe_gamma = safe_delta = 0.5
        _validate_parameters_and_value_threshold(safe_alpha, safe_beta, safe_gamma, safe_delta, ProblemType.OPTIMISATION, None)

        with self.assertRaises(ValueError):
            _validate_parameters_and_value_threshold(-0.5, safe_beta, safe_gamma, safe_delta, ProblemType.OPTIMISATION, None)

        with self.assertRaises(ValueError):
            _validate_parameters_and_value_threshold(safe_alpha, -0.5, safe_gamma, safe_delta, ProblemType.OPTIMISATION, None)

        with self.assertRaises(ValueError):
            _validate_parameters_and_value_threshold(safe_alpha, safe_beta, -0.5, safe_delta, ProblemType.OPTIMISATION, None)

        with self.assertRaises(ValueError):
            _validate_parameters_and_value_threshold(safe_alpha, safe_beta, safe_gamma, -0.5, ProblemType.OPTIMISATION, None)


class TestDistribution(unittest.TestCase):
    def test_get_node_distribution(self):
        """ Test the node distribution calculation.

        This test is based on model 2.0 and for a given knapsack that was manually calculated.
        """

        KnapsackItem._knapsack_items_count = 0  # Hack to account that tests can be run out of order or may fail, changing the number of KnapsackItems created.

        knapsack_items = [KnapsackItem(100, 50), KnapsackItem(50, 30), KnapsackItem(30, 60), KnapsackItem(140, 120), KnapsackItem(40, 25)]
        knapsack_capacity = 100
        knapsack_instance = KnapsackInstance.create(knapsack_items, knapsack_capacity)

        param_alpha = 0.75
        param_beta = 0.6
        param_gamma = 0.2
        param_delta = 0.6

        node_distribution = get_node_distribution(knapsack_instance, param_alpha, param_beta, param_gamma, param_delta)

        self.assertAlmostEqual(sum(node_distribution.values()), 1.0)

        sorted_node_distribution = {key: value for key, value in sorted(node_distribution.items(), key=lambda item: item[1], reverse=True)}

        self.assertEqual(list(sorted_node_distribution.keys())[0], 71368893422976312)
        self.assertEqual(list(sorted_node_distribution.keys())[1], 28842055690456967)
        self.assertEqual(list(sorted_node_distribution.keys())[2], 34553217198694031)
        self.assertEqual(list(sorted_node_distribution.keys())[3], 32088055266112979)
        self.assertEqual(list(sorted_node_distribution.keys())[4], 48833112867671063)

        self.assertAlmostEqual(node_distribution[71368893422976312], 0.776998932560427)
        self.assertAlmostEqual(node_distribution[28842055690456967], 0.162691836871925)
        self.assertAlmostEqual(node_distribution[34553217198694031], 0.0440568067760513)
        self.assertAlmostEqual(node_distribution[32088055266112979], 0.0129266429474177)
        self.assertAlmostEqual(node_distribution[48833112867671063],  0.00332578084417862)

        self.assertEqual(KnapsackInstance.instance_by_hash[71368893422976312].standing_knapsack_items, (knapsack_items[0], knapsack_items[1]))
        self.assertEqual(KnapsackInstance.instance_by_hash[28842055690456967].standing_knapsack_items, (knapsack_items[0], knapsack_items[4]))
        self.assertEqual(KnapsackInstance.instance_by_hash[34553217198694031].standing_knapsack_items, (knapsack_items[1], knapsack_items[4]))
        self.assertEqual(KnapsackInstance.instance_by_hash[32088055266112979].standing_knapsack_items, (knapsack_items[1], knapsack_items[2]))
        self.assertEqual(KnapsackInstance.instance_by_hash[48833112867671063].standing_knapsack_items, (knapsack_items[2], knapsack_items[4]))

    def test_get_node_distribution_paper_appendix_1_optimisation(self):
        """ Test the node distribution calculation.

        This test is based on model 2.0 and uses the knapsack example in Chapter 1 Appendix 1 (8.1) for the optimisation instance that was manually calculated.
        """

        KnapsackItem._knapsack_items_count = 0  # Hack to account that tests can be run out of order or may fail, changing the number of KnapsackItems created.

        knapsack_items = [KnapsackItem(12, 7), KnapsackItem(8, 5), KnapsackItem(14, 8), KnapsackItem(9, 4)]
        knapsack_capacity = 16
        knapsack_instance = KnapsackInstance.create(knapsack_items, knapsack_capacity)

        param_alpha = 0.70
        param_beta = 0.75
        param_gamma = 0.4
        param_delta = 0.5

        node_distribution = get_node_distribution(knapsack_instance, param_alpha, param_beta, param_gamma, param_delta)

        self.assertAlmostEqual(sum(node_distribution.values()), 1.0)

        sorted_node_distribution = {key: value for key, value in sorted(node_distribution.items(), key=lambda item: item[1], reverse=True)}

        self.assertEqual(list(sorted_node_distribution.keys())[0], 37853183573148781)
        self.assertEqual(list(sorted_node_distribution.keys())[1], 31360667515814717)
        self.assertEqual(list(sorted_node_distribution.keys())[2], 18184359099941993)
        self.assertEqual(list(sorted_node_distribution.keys())[3], 39006237199894810)

        self.assertAlmostEqual(node_distribution[37853183573148781], 0.7487276377548032)
        self.assertAlmostEqual(node_distribution[31360667515814717], 0.1534085161146231)
        self.assertAlmostEqual(node_distribution[18184359099941993], 0.08380264655104011)
        self.assertAlmostEqual(node_distribution[39006237199894810], 0.014061199579533638)

        self.assertEqual(KnapsackInstance.instance_by_hash[37853183573148781].standing_knapsack_items, (knapsack_items[0], knapsack_items[1], knapsack_items[3]))
        self.assertEqual(KnapsackInstance.instance_by_hash[31360667515814717].standing_knapsack_items, (knapsack_items[0], knapsack_items[2]))
        self.assertEqual(KnapsackInstance.instance_by_hash[18184359099941993].standing_knapsack_items, (knapsack_items[2], knapsack_items[3]))
        self.assertEqual(KnapsackInstance.instance_by_hash[39006237199894810].standing_knapsack_items, (knapsack_items[1], knapsack_items[2]))

    def test_print_node_distribution(self):
        """ Test the printed message from print_node_distribution.

        This test is based on model 2.0 and uses the knapsack example in Chapter 1 Appendix 1 (8.1) for the optimisation instance.
        """

        knapsack_items = [KnapsackItem(12, 7), KnapsackItem(8, 5), KnapsackItem(14, 8), KnapsackItem(9, 4)]
        knapsack_capacity = 16
        knapsack_instance = KnapsackInstance.create(knapsack_items, knapsack_capacity)

        param_alpha = 0.70
        param_beta = 0.75
        param_gamma = 0.4
        param_delta = 0.5

        node_distribution = get_node_distribution(knapsack_instance, param_alpha, param_beta, param_gamma, param_delta)

        original = sys.stdout
        try:
            buf = io.StringIO()
            sys.stdout = buf
            print_node_distribution(knapsack_instance, node_distribution, (param_alpha, param_beta, param_gamma, param_delta), 0.01)
            expected_print = "Inputs\n\nParameters: α = 0.7, β = 0.75, γ = 0.4, δ = 0.5\n\nKnapsack Problem Variant: Optimisation\n\nItems: (v: 12, w: 7), (v: 8, w: 5), (v: 14, w: 8), (v: 9, w: 4)\n\nBudget: 16\n\n-------------------------------------\n\nOutput\n\nTerminal Nodes (*** for optimal):\n[1, 1, 0, 1] - Σv: 29, Σw: 16 / 16 - 74.873% ***\n[1, 0, 1, 0] - Σv: 26, Σw: 15 / 16 - 15.341%\n[0, 0, 1, 1] - Σv: 23, Σw: 12 / 16 - 8.380%\n[0, 1, 1, 0] - Σv: 22, Σw: 13 / 16 - 1.406%\n\nTotal Distribution: 1.0\n\nNumber of Terminal Nodes: 4 (unmerged: 4)\n\n"

            self.assertEqual(buf.getvalue(), expected_print)
        finally:
            sys.stdout = original

    def test_get_node_distribution_paper_appendix_1_decision(self):
        """ Test the decision witness finding calculation.

        This test is based on model 2.0 and uses the knapsack example in Chapter 1 Appendix 1 (8.1) for the decision instance that was manually calculated."""

        knapsack_items = [KnapsackItem(12, 7), KnapsackItem(8, 5), KnapsackItem(14, 8), KnapsackItem(9, 4)]
        knapsack_capacity = 16
        knapsack_instance = KnapsackInstance.create(knapsack_items, knapsack_capacity)

        param_alpha = 0.70
        param_beta = 0.75
        param_gamma = 0.4
        param_delta = 0.5
        value_threshold = 27

        satisfiable_percent = solve_decision_variant(knapsack_instance, param_alpha, param_beta, param_gamma, param_delta, value_threshold)

        self.assertAlmostEqual(satisfiable_percent, 0.9001191238392088)
